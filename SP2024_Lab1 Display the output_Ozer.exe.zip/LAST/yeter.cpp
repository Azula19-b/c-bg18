// File: SP2024_ProgramWithVariables_Martinez.cpp
#include <iostream>
using namespace std;

int main() {
    // Declare variables
    string word1, word2;
    float num1, num2, num3, average;

    // Display messages and get input
    cout << "Enter 2 words: ";
    cin >> word1 >> word2;

    cout << "Enter 3 decimal numbers: ";
    cin >> num1 >> num2 >> num3;

    // Calculate average
    average = (num1 + num2 + num3) / 3;

    // Display 11 output lines
    cout << "File SP2024_ProgramWithVariables_Martinez.cpp" << endl;
    cout << "Spring 2024 semester - LUIS MARTINEZ" << endl;
    cout << "Word 1: " << word1 << endl;
    cout << "Word 2: " << word2 << endl;
    cout << "First number: " << num1 << endl;
    cout << "Second number: " << num2 << endl;
    cout << "Third number: " << num3 << endl;
    cout << "Average of " << num1 << ", " << num2 << ", " << num3 << " is: " << average << endl;

    return 0;
}
